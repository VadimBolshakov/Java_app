package com.example.charter_3;

import androidx.appcompat.app.AppCompatActivity;

import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void sendMessage(View view){
        //TextView textView=(TextView) findViewById(R.id.text_view);
        EditText editText=(EditText) findViewById(R.id.edit_text);
        Toast toast=Toast.makeText(this,"Welcome "+editText.getText(),Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP,10,160);
        toast.show();
        //textView.setText("Welcome," + editText.getText());
    }
}
